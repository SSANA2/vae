# vae
COCO VAE comparision

CNN-based
VAE
IWAE
